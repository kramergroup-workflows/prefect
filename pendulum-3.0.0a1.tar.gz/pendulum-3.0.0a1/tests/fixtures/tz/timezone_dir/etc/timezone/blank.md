# Blank file

Necessary for environments, which not handle empty folder synchronization well, to be sure the parent folder is created.

The `/etc/timezone` folder is necessary to ensure that the package not fail if that folder exists.
