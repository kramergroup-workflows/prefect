from __future__ import annotations

from .parsing.exceptions import ParserError  # noqa


class PendulumException(Exception):

    pass
